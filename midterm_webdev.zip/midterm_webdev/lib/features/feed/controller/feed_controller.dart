import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:midterm_webdev/core/models/post_model.dart';
import 'package:midterm_webdev/features/feed/state/feed_state.dart';
import 'package:midterm_webdev/features/profile/controller/user_controller.dart';

final feedControllerProvider = StateNotifierProvider<FeedController, FeedState>((ref) {
  return FeedController(
    ref: ref,
  );
});

class FeedController extends StateNotifier<FeedState> {
  FeedController({
    required this.ref,
  }) : super(FeedState.initial());

  final Ref ref;

  void addPost({
    required String title,
    required String description,
  }) {
    final username = ref.read(userControllerProvider);
    final postModel = PostModel(
      username: username,
      title: title,
      desctiprion: description,
      likes: 0,
      dislikes: 0,
    );

    List<PostModel> newList = [postModel, ...state.postModels];

    state = state.copyWith(
      postModels: newList,
    );
  }

  // void toggleLike(int index) {
  //   final postModel = state.postModels[index];

  //   List<PostModel> newList = List.from(state.postModels);
  //   newList[index] = postModel.copyWith(
  //     title: title,
  //     desctiprion: description,
  //   );

  //   state = state.copyWith(
  //     postModels: newList,
  //   );
  // }

  void editPost({
    required int index,
    required String title,
    required String description,
  }) {
    final postModel = state.postModels[index];

    List<PostModel> newList = List.from(state.postModels);
    newList[index] = postModel.copyWith(
      title: title,
      desctiprion: description,
    );

    state = state.copyWith(
      postModels: newList,
    );
  }

  void delete(int index) {
    List<PostModel> newList = List.from(state.postModels)..removeAt(index);

    state = state.copyWith(
      postModels: newList,
    );
  }
}
