import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:midterm_webdev/features/add_post/add_post_screen.dart';
import 'package:midterm_webdev/features/feed/controller/feed_controller.dart';
import 'package:midterm_webdev/features/feed/widgets/post_card.dart';
import 'package:midterm_webdev/features/profile/profile_screen.dart';

class FeedScreen extends ConsumerWidget {
  const FeedScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(feedControllerProvider);

    return Scaffold(
      floatingActionButton: GestureDetector(
        onTap: () {
          Navigator.push(context, AddPostScreen.route());
        },
        child: Container(
          width: 60,
          height: 60,
          decoration: const BoxDecoration(
            color: Color(0xFFC9C5CF),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.add),
        ),
      ),
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: const AutoSizeText(
          'Feed',
          maxLines: 1,
          style: TextStyle(
            fontSize: 24,
            color: Colors.white,
          ),
        ),
        leadingWidth: 64,
        leading: Align(
          alignment: Alignment.centerRight,
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                ProfileScreen.route(),
              );
            },
            child: Container(
              height: 44,
              width: 44,
              decoration: const BoxDecoration(
                color: Colors.brown,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.person,
                color: Colors.white,
              ),
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: Colors.white,
          ),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          const SliverToBoxAdapter(child: SizedBox(height: 16)),
          SliverSafeArea(
            top: false,
            sliver: SliverPadding(
              padding: const EdgeInsets.only(bottom: 12),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate((context, index) {
                  return Container(
                    margin: EdgeInsets.only(top: index == 0 ? 0 : 20),
                    child: PostCard(
                      postModel: state.postModels[index],
                      index: index,
                    ),
                  );
                }, childCount: state.postModels.length),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
