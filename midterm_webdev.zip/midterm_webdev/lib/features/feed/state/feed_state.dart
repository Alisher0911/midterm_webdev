import 'package:equatable/equatable.dart';
import 'package:midterm_webdev/core/models/post_model.dart';

class FeedState extends Equatable {
  const FeedState({
    required this.postModels,
  });

  final List<PostModel> postModels;

  factory FeedState.initial() {
    return FeedState(
      postModels: List.from(PostModel.posts),
    );
  }

  FeedState copyWith({
    List<PostModel>? postModels,
  }) {
    return FeedState(
      postModels: postModels ?? this.postModels,
    );
  }

  @override
  List<Object?> get props => [
        postModels,
      ];
}
