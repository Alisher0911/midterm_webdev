import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:midterm_webdev/core/models/post_model.dart';
import 'package:midterm_webdev/core/widgets/custom_button.dart';
import 'package:midterm_webdev/core/widgets/custom_svg_button.dart';
import 'package:midterm_webdev/features/edit_post/edit_post_screen.dart';

class PostCard extends StatefulWidget {
  const PostCard({
    required this.postModel,
    required this.index,
    super.key,
  });

  final PostModel postModel;
  final int index;

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  int _likes = 0;
  int _dislikes = 0;

  bool _isLiked = false;
  bool _isDisliked = false;

  @override
  void initState() {
    _likes = widget.postModel.likes;
    _dislikes = widget.postModel.dislikes;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          EditPostScreen.route(
            index: widget.index,
            postModel: widget.postModel,
          ),
        );
      },
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(
              width: 1,
              color: Colors.white38,
            ),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: const Icon(
                Icons.person,
                color: Colors.black,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Username
                  AutoSizeText(
                    widget.postModel.username,
                    maxLines: 1,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Title
                  Text(
                    widget.postModel.title,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 4),

                  // Description
                  Text(
                    widget.postModel.desctiprion,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w400,
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Image
                  Container(
                    height: 200,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.image_rounded,
                      size: 50,
                    ),
                  ),

                  const SizedBox(height: 12),

                  Row(
                    children: [
                      // Like
                      CustomButton(
                        iconData: Icons.favorite_border,
                        onTap: () {
                          setState(() {
                            if (_isLiked) {
                              _isLiked = false;
                              _likes--;
                            } else {
                              _isLiked = true;
                              _likes++;
                            }
                          });
                        },
                        backgroundColor: _isLiked ? Colors.green : Colors.transparent,
                        padding: const EdgeInsets.only(top: 2),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '$_likes',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(width: 12),

                      // Dislike
                      CustomImageButton(
                        asset: 'assets/dislike.png',
                        onTap: () {
                          setState(() {
                            if (_isDisliked) {
                              _isDisliked = false;
                              _dislikes--;
                            } else {
                              _isDisliked = true;
                              _dislikes++;
                            }
                          });
                        },
                        backgroundColor: _isDisliked ? Colors.red : Colors.transparent,
                        padding: const EdgeInsets.fromLTRB(10, 13, 10, 10),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '$_dislikes',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
