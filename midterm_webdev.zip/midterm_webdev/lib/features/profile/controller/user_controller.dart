import 'package:hooks_riverpod/hooks_riverpod.dart';

final userControllerProvider = StateNotifierProvider<UserController, String>((ref) {
  return UserController(
    ref: ref,
  );
});

class UserController extends StateNotifier<String> {
  UserController({
    required this.ref,
  }) : super('User123456');

  final Ref ref;

  void changeUsername(String text) {
    state = text;
  }
}
