import 'package:flutter/material.dart';

class CustomImageButton extends StatelessWidget {
  const CustomImageButton({
    required this.asset,
    required this.onTap,
    required this.backgroundColor,
    this.color = Colors.white,
    this.padding = EdgeInsets.zero,
    super.key,
  });

  final String asset;
  final VoidCallback? onTap;
  final Color backgroundColor;
  final Color color;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: backgroundColor,
        ),
        child: Padding(
          padding: padding,
          child: Image.asset(
            asset,
            fit: BoxFit.scaleDown,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
