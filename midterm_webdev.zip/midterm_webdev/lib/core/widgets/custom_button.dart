import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({
    required this.iconData,
    required this.onTap,
    required this.backgroundColor,
    this.color = Colors.white,
    this.size = 24,
    this.padding = EdgeInsets.zero,
    super.key,
  });

  final IconData iconData;
  final VoidCallback? onTap;
  final Color backgroundColor;
  final Color color;
  final double size;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: backgroundColor,
        ),
        child: Padding(
          padding: padding,
          child: Icon(
            iconData,
            color: color,
            size: size,
          ),
        ),
      ),
    );
  }
}
