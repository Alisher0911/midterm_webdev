import 'package:equatable/equatable.dart';

class PostModel extends Equatable {
  final String username;
  final String title;
  final String desctiprion;
  final String? image;
  final int likes;
  final int dislikes;

  const PostModel({
    required this.username,
    required this.title,
    required this.desctiprion,
    this.image,
    required this.likes,
    required this.dislikes,
  });

  static final List<PostModel> posts = [
    const PostModel(username: 'Alisher', title: 'Asdasd', desctiprion: 'Desc1', likes: 4, dislikes: 12),
    const PostModel(username: 'Orazbay', title: 'Asd2', desctiprion: 'Desc2', likes: 6, dislikes: 13),
    const PostModel(username: 'John', title: 'Asd3', desctiprion: 'Desc3', likes: 4, dislikes: 13),
    const PostModel(username: 'Mike', title: 'Asd4', desctiprion: 'Desc4', likes: 4, dislikes: 11),
  ];

  @override
  List<Object?> get props => [
        username,
        title,
        desctiprion,
        image,
      ];

  PostModel copyWith({
    String? username,
    String? title,
    String? desctiprion,
    String? image,
    int? likes,
    int? dislikes,
  }) {
    return PostModel(
      username: username ?? this.username,
      title: title ?? this.title,
      desctiprion: desctiprion ?? this.desctiprion,
      image: image ?? this.image,
      likes: likes ?? this.likes,
      dislikes: dislikes ?? this.dislikes,
    );
  }
}
