import 'package:flutter/material.dart';
import 'package:midterm_webdev/theme/app_colors.dart';

ThemeData theme() {
  return ThemeData(
    splashColor: Colors.transparent,
    highlightColor: Colors.transparent,
    scaffoldBackgroundColor: AppColors.background,
    colorScheme: const ColorScheme(
      primary: Colors.transparent,
      onPrimary: Colors.transparent,
      secondary: Colors.transparent,
      onSecondary: Colors.transparent,
      background: Colors.transparent,
      onBackground: Colors.transparent,
      surface: Colors.transparent,
      onSurface: Colors.transparent,
      error: Colors.transparent,
      onError: Colors.transparent,
      brightness: Brightness.light,
      tertiary: Colors.transparent,
    ),
  );
}
