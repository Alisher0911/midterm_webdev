import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF150B25);
}
