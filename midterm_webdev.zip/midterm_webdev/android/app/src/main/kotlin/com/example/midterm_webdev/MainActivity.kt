package com.example.midterm_webdev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
